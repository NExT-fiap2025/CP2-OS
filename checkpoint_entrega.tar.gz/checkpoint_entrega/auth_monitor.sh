#!/bin/bash

# Este script usa 'tail -f' para seguir o arquivo de log em tempo real.
# O pipe '|' envia cada nova linha para o loop 'while'.
# O loop adiciona a data e hora atual a cada linha recebida.

stdbuf -oL tail -n 0 -f /var/log/auth.log | while read line
do
  # Imprime a data/hora formatada + a linha original do log
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $line"
done
