#!/bin/bash

# Loop infinito para manter o script em execução
while true
do
  # Imprime um cabeçalho com a data e hora da verificação
  echo "--- Verificando usuários logados em $(date '+%Y-%m-%d %H:%M:%S') ---"

  # Executa o comando 'who' e imprime a saída
  who

  # Aguarda 30 segundos antes da próxima verificação. Você pode ajustar este tempo.
  sleep 30
done
